/* ===========================================================
   TS Autofill — ক্রোম ওয়েব স্টোরের চেহারায় পপআপ
   ===========================================================
   সাইটে ঢুকলে একবার দেখায়। বন্ধ করলে সেই দিনের মতো আর আসে না।

   বসানোর নিয়ম — </body> এর ঠিক আগে:
       <script src="assets/js/tsaf-promo.js" defer></script>

   কিছু বদলাতে চাইলে নিচের TSAF_CONFIG অংশটুকুই যথেষ্ট।
   =========================================================== */
(function () {
  'use strict';

  /* ───────────── সেটিংস ───────────── */
  var TSAF_CONFIG = {
    storeUrl: 'https://chromewebstore.google.com/detail/TS%20Autofill/jonaaangpogelopfopgbacijjagbdbpi',

    /* স্টোরের তথ্য */
    name:   'TS Autofill',
    icon:   'https://lh3.googleusercontent.com/bUMjnHHdPuhF1uhgHONBcsvN-UDBSpMNXabov7Bpqf5okyMaTqWQBd_5ZC2qesl5DnAg7PsNClugZeRdcO4fYaxI=s128-rj-sc0x00ffffff',
    rating: '5.0',

    hideDays: 365,     // Disabled - hidden for 1 year
    delay:    900,     // পাতা খোলার কত মিলিসেকেন্ড পরে আসবে
    key:      'v2'     // বদলালে যারা আগে বন্ধ করেছিলেন তারাও আবার দেখবেন
  };

  var STORE_KEY = 'tsaf_promo_hidden_' + TSAF_CONFIG.key;

  function isHidden() {
    if (TSAF_CONFIG.hideDays <= 0) return false;
    try {
      return parseInt(localStorage.getItem(STORE_KEY) || '0', 10) > Date.now();
    } catch (e) { return false; }
  }

  function markHidden() {
    if (TSAF_CONFIG.hideDays <= 0) return;
    try {
      localStorage.setItem(STORE_KEY, String(Date.now() + TSAF_CONFIG.hideDays * 864e5));
    } catch (e) { /* স্টোরেজ বন্ধ থাকলেও চলবে */ }
  }

  if (isHidden()) return;

  /* ───────────── স্টাইল ───────────── */
  var css = ''
    + '#tsafPromo{position:fixed;inset:0;z-index:2147483000;display:flex;'
    + 'align-items:center;justify-content:center;padding:16px;'
    + 'background:rgba(32,33,36,.6);opacity:0;transition:opacity .22s ease}'
    + '#tsafPromo.on{opacity:1}'
    + '#tsafPromo *{box-sizing:border-box}'

    + '.tsaf-box{position:relative;width:100%;max-width:500px;max-height:92vh;'
    + 'overflow-y:auto;background:#fff;border-radius:12px;'
    + 'box-shadow:0 12px 42px rgba(32,33,36,.4);color:#202124;'
    + "font-family:'Hind Siliguri',Roboto,Arial,system-ui,sans-serif;"
    + 'transform:translateY(14px);transition:transform .26s cubic-bezier(.22,1,.36,1)}'
    + '#tsafPromo.on .tsaf-box{transform:none}'

    /* স্টোরের উপরের বার */
    + '.tsaf-bar{display:flex;align-items:center;gap:9px;padding:12px 52px 12px 18px;'
    + 'border-bottom:1px solid #e8eaed}'
    + '.tsaf-bar img{width:22px;height:22px;flex:0 0 auto}'
    + '.tsaf-bar span{font-size:14px;color:#5f6368;font-weight:500;'
    + 'font-family:Roboto,Arial,sans-serif}'

    /* বন্ধ করার বোতাম */
    + '.tsaf-x{position:absolute;top:9px;right:10px;width:34px;height:34px;border:0;'
    + 'border-radius:50%;background:transparent;color:#5f6368;font-size:22px;'
    + 'line-height:1;cursor:pointer;display:flex;align-items:center;'
    + 'justify-content:center;transition:background .15s}'
    + '.tsaf-x:hover{background:#f1f3f4;color:#202124}'
    + '.tsaf-x:focus-visible{outline:2px solid #1a73e8;outline-offset:1px}'

    /* এক্সটেনশনের পরিচয় */
    + '.tsaf-top{display:flex;gap:16px;padding:18px 18px 16px;align-items:flex-start}'
    + '.tsaf-ico{width:64px;height:64px;flex:0 0 64px;border-radius:12px;'
    + 'background:#f1f3f4;object-fit:contain}'
    + '.tsaf-meta{flex:1;min-width:0}'
    + '.tsaf-name{font-size:22px;font-weight:700;line-height:1.3;margin:0 0 5px;'
    + 'color:#202124}'
    + '.tsaf-rate{display:flex;align-items:center;gap:6px;font-size:13px;'
    + 'color:#5f6368;margin-bottom:3px;flex-wrap:wrap}'
    + '.tsaf-rate b{color:#202124;font-weight:600}'
    + '.tsaf-stars{color:#1a73e8;letter-spacing:1px;font-size:13px}'
    /* Add to Chrome বোতাম */
    + '.tsaf-add{display:block;margin:0 18px 16px;height:44px;line-height:44px;'
    + 'border-radius:22px;background:#1a73e8;color:#fff;text-align:center;'
    + 'font-size:15px;font-weight:600;text-decoration:none;'
    + 'font-family:Roboto,Arial,sans-serif;'
    + 'transition:background .15s,box-shadow .15s}'
    + '.tsaf-add:hover{background:#1b66ca;box-shadow:0 1px 3px rgba(60,64,67,.3)}'

    /* ভেতরের অংশ */
    + '.tsaf-sec{padding:16px 18px;border-top:1px solid #e8eaed}'
    + '.tsaf-h{font-size:15px;font-weight:600;margin:0 0 10px;color:#202124}'

    + '.tsaf-new{display:flex;gap:9px;align-items:flex-start;background:#e8f0fe;'
    + 'border-radius:8px;padding:11px 13px;margin-bottom:13px}'
    + '.tsaf-new .dot{flex:0 0 auto;background:#1a73e8;color:#fff;font-size:11px;'
    + 'font-weight:600;padding:2px 9px;border-radius:10px;margin-top:2px}'
    + '.tsaf-new p{margin:0;font-size:13.5px;line-height:1.65;color:#174ea6}'

    + '.tsaf-list{list-style:none;margin:0;padding:0}'
    + '.tsaf-list li{position:relative;padding-left:22px;margin-bottom:8px;'
    + 'font-size:13.5px;line-height:1.6;color:#3c4043}'
    + '.tsaf-list li:last-child{margin-bottom:0}'
    + '.tsaf-list li:before{content:"";position:absolute;left:5px;top:8px;'
    + 'width:6px;height:6px;border-radius:50%;background:#1a73e8}'

    /* ধাপ */
    + '.tsaf-steps{counter-reset:s;list-style:none;margin:0;padding:0}'
    + '.tsaf-steps li{counter-increment:s;position:relative;padding-left:30px;'
    + 'margin-bottom:9px;font-size:13.5px;line-height:1.6;color:#3c4043}'
    + '.tsaf-steps li:last-child{margin-bottom:0}'
    + '.tsaf-steps li:before{content:counter(s);position:absolute;left:0;top:1px;'
    + 'width:21px;height:21px;border-radius:50%;background:#e8f0fe;color:#1a73e8;'
    + 'font-size:11.5px;font-weight:700;display:flex;align-items:center;'
    + 'justify-content:center}'

    + '.tsaf-foot{padding:12px 18px 16px;border-top:1px solid #e8eaed;text-align:center}'
    + '.tsaf-later{background:none;border:0;color:#5f6368;font-size:13.5px;'
    + 'cursor:pointer;padding:8px 18px;border-radius:6px;font-family:inherit}'
    + '.tsaf-later:hover{background:#f1f3f4;color:#202124}'

    + '@media(max-width:480px){'
    + '.tsaf-top{gap:13px;padding:16px 16px 14px}'
    + '.tsaf-ico{width:54px;height:54px;flex:0 0 54px}'
    + '.tsaf-name{font-size:19px}'
    + '.tsaf-sec{padding:14px 16px}'
    + '.tsaf-add{margin:0 16px 14px}'
    + '}';

  /* ───────────── গঠন ───────────── */
  var C = TSAF_CONFIG;

  var html = ''
    + '<div class="tsaf-box" role="dialog" aria-modal="true" aria-labelledby="tsafName">'

    + '<button class="tsaf-x" type="button" aria-label="বন্ধ করুন">&times;</button>'

    + '<div class="tsaf-bar">'
    +   '<img src="https://fonts.gstatic.com/s/i/productlogos/chrome_store/v7/192px.svg" '
    +        'alt="" onerror="this.style.display=\'none\'">'
    +   '<span>Chrome Web Store</span>'
    + '</div>'

    + '<div class="tsaf-top">'
    +   '<img class="tsaf-ico" src="' + C.icon + '" alt="' + C.name + '" '
    +        'onerror="this.style.display=\'none\'">'
    +   '<div class="tsaf-meta">'
    +     '<h2 class="tsaf-name" id="tsafName">' + C.name + '</h2>'
    +     '<div class="tsaf-rate">'
    +       '<b>' + C.rating + '</b>'
    +       '<span class="tsaf-stars">★★★★★</span>'
    +     '</div>'
    +   '</div>'
    + '</div>'

    + '<a class="tsaf-add" href="' + C.storeUrl + '" target="_blank" rel="noopener">'
    +   'Add to Chrome</a>'

    + '<div class="tsaf-sec">'
    +   '<h3 class="tsaf-h">এটি কী করে</h3>'

    +   '<div class="tsaf-new">'
    +     '<span class="dot">নতুন</span>'
    +     '<p><b>এখন পাসপোর্ট দিয়েও অটোফিল করা যায়।</b> পুরনো আবেদন ফরম (BGD) এর পাশাপাশি '
    +     'পাসপোর্ট ব্যবহার করেও আপনার ইন্ডিয়ান ভিসার ফরম পূরণ করতে পারবেন। যেটি হাতের কাছে '
    +     'আছে, সেটি দিলেই হবে।</p>'
    +   '</div>'

    +   '<ul class="tsaf-list">'
    +     '<li>ইন্ডিয়ান ভিসা আবেদনের ফর্ম এক ক্লিকে পূরণ</li>'
    +     '<li>বাংলাদেশ পুলিশ ক্লিয়ারেন্সের ফর্মও একই প্রোফাইল দিয়ে</li>'
    +     '<li>আবেদন ফরম (BGD) অথবা পাসপোর্ট — দুটোর যেকোনোটি দিয়েই চলে</li>'
    +     '<li>কোন ঘরগুলো নিজে থেকে পূরণ হলো তা চিহ্ন দিয়ে দেখায়</li>'
    +     '<li>একাধিক প্রোফাইল সংরক্ষণ — পরিবারের সবার তথ্য আলাদা</li>'
    +     '<li>সম্পূর্ণ এডিটরে যেকোনো তথ্য নিজে ঠিক করে নেওয়া যায়</li>'
    +   '</ul>'
    + '</div>'

    + '<div class="tsaf-sec">'
    +   '<h3 class="tsaf-h">কীভাবে যোগ করবেন</h3>'
    +   '<ol class="tsaf-steps">'
    +     '<li>উপরের <b>Add to Chrome</b> বোতামে চাপ দিন</li>'
    +     '<li>স্টোরের পাতায় আবার <b>Add to Chrome</b> ক্লিক করুন</li>'
    +     '<li>জানতে চাইলে <b>Add extension</b> চাপুন</li>'
    +     '<li>ঠিকানা বারের পাশে আইকনটি দেখা যাবে — কাজ শুরু</li>'
    +   '</ol>'
    + '</div>'

    + '<div class="tsaf-foot">'
    +   '<button class="tsaf-later" type="button">পরে দেখব</button>'
    + '</div>'

    + '</div>';

  /* ───────────── দেখানো ও বন্ধ করা ───────────── */
  function show() {
    if (document.getElementById('tsafPromo')) return;

    var style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);

    var wrap = document.createElement('div');
    wrap.id = 'tsafPromo';
    wrap.innerHTML = html;
    document.body.appendChild(wrap);

    var prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    requestAnimationFrame(function () { wrap.classList.add('on'); });

    function close() {
      markHidden();
      wrap.classList.remove('on');
      document.body.style.overflow = prevOverflow;
      document.removeEventListener('keydown', onKey);
      setTimeout(function () {
        if (wrap.parentNode) wrap.parentNode.removeChild(wrap);
        if (style.parentNode) style.parentNode.removeChild(style);
      }, 260);
    }

    function onKey(e) { if (e.key === 'Escape') close(); }

    wrap.querySelector('.tsaf-x').addEventListener('click', close);
    wrap.querySelector('.tsaf-later').addEventListener('click', close);
    wrap.addEventListener('click', function (e) { if (e.target === wrap) close(); });
    wrap.querySelector('.tsaf-add').addEventListener('click', function () {
      setTimeout(close, 150);
    });

    document.addEventListener('keydown', onKey);
    wrap.querySelector('.tsaf-x').focus();
  }

  function start() { setTimeout(show, TSAF_CONFIG.delay); }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
