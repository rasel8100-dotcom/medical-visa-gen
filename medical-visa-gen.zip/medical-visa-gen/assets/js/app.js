/* ===========================================================
   Medical Visa Undertaking Generator — app.js  (v2.1)
   100% client-side.
   • Upload Invitation Letter (PDF) → read only needed fields.
   • Patient alone or with 1–3 attendants; wording adapts.
   • Pick a person → PREPARE step (two clear document cards):
       1) Undertaking  — optional applicant signature (edit:
          crop / brightness / contrast / white-removal).
       2) Parental Consent — shown only if the chosen person is
          under 18; father / mother inputs + optional father &
          mother signatures (each editable / skippable).
   • One upload → download everyone (reopen picker / selector).
   • Email read but not printed. Signatures embedded small.
   • v2.1: Mission selector popup — 5 missions supported.
   =========================================================== */
(function () {
  "use strict";
  const { PDFDocument, StandardFonts, rgb } = PDFLib;
  if (window.pdfjsLib) pdfjsLib.GlobalWorkerOptions.workerSrc = "assets/vendor/pdf.worker.min.js";
  const $ = id => document.getElementById(id);
  const SIZE_LIMIT = 480 * 1024;
  const MIN_PDF_SIZE = 10 * 1024;   // 10 KB
  const MAX_PDF_SIZE = 300 * 1024;  // 300 KB
  const MAX_ATT = 3;

  const FIELDS = ["FULL_NAME", "PASSPORT_NO", "HOSPITAL_NAME", "HOSPITAL_FULL_ADDRESS", "PURPOSE_OF_TREATMENT", "DATE_OF_FILLING", "MOBILE_NUMBER"];
  const REQUIRED = FIELDS.slice();
  const STORE_KEY = "mv.undertaking.v14";

  // ভবিষ্যতে YouTube link এখানে দিন, যেমন:
  // "https://www.youtube.com/embed/XXXXXXXXXXX"
  // খালি রাখলে "শীঘ্রই আসছে" দেখাবে
  const VIDEO_URL = "";

  // ===========================================================
  //  MISSION DATA
  // ===========================================================
  const MISSIONS = [
    {
      id: "dhaka",
      city: "Dhaka",
      type: "High Commission",
      badge: "HCI",
      icon: "🏛️",
      officer: "The Visa Officer",
      line1: "High Commission of India",
      line2: "Dhaka, Bangladesh",
      shortName: "High Commission of India"
    },
    {
      id: "chittagong",
      city: "Chittagong",
      type: "Assistant High Commission",
      badge: "AHCI",
      icon: "🏢",
      officer: "The Visa Officer",
      line1: "Assistant High Commission of India",
      line2: "Chittagong, Bangladesh",
      shortName: "Assistant High Commission of India"
    },
    {
      id: "rajshahi",
      city: "Rajshahi",
      type: "Assistant High Commission",
      badge: "AHCI",
      icon: "🏢",
      officer: "The Visa Officer",
      line1: "Assistant High Commission of India",
      line2: "Rajshahi, Bangladesh",
      shortName: "Assistant High Commission of India"
    },
    {
      id: "sylhet",
      city: "Sylhet",
      type: "Assistant High Commission",
      badge: "AHCI",
      icon: "🏢",
      officer: "The Visa Officer",
      line1: "Assistant High Commission of India",
      line2: "Sylhet, Bangladesh",
      shortName: "Assistant High Commission of India"
    },
    {
      id: "khulna",
      city: "Khulna",
      type: "Assistant High Commission",
      badge: "AHCI",
      icon: "🏢",
      officer: "The Visa Officer",
      line1: "Assistant High Commission of India",
      line2: "Khulna, Bangladesh",
      shortName: "Assistant High Commission of India"
    }
  ];
  let selectedMission = MISSIONS[0];

  let target = { role: "patient", idx: null };
  let parsed = null;
  let lastBytes = null, lastName = "undertaking.pdf";
  let preparedKey = null;

  // ----- signature slots: applicant / father / mother -----
  function newSlot() { return { data: null, source: null, crop: null, rot: 0, adjust: { bright: 0, contrast: 0, white: 0 } }; }
  const SIG = { applicant: newSlot(), father: newSlot(), mother: newSlot() };
  const SLOT_UI = {
    applicant: { wrap: "sigDropWrap", prev: "sigPrev", img: "sigImg" },
    father: { wrap: "fSigWrap", prev: "fSigPrev", img: "fSigImg" },
    mother: { wrap: "mSigWrap", prev: "mSigPrev", img: "mSigImg" }
  };
  let activeSlot = "applicant", sigBackup = null;

  // ---------------- helpers ----------------
  function toast(msg, isErr) {
    let t = $("toastMini");
    if (!t) { t = document.createElement("div"); t.id = "toastMini"; t.className = "toast"; document.body.appendChild(t); }
    t.textContent = msg;
    t.className = "toast show" + (isErr ? " err" : "");
    clearTimeout(t._t); t._t = setTimeout(() => (t.className = "toast"), 3600);
  }
  function fmtSize(b) {
    if (b < 1024) return b + " B";
    if (b < 1024 * 1024) return (b / 1024).toFixed(1) + " KB";
    return (b / (1024 * 1024)).toFixed(2) + " MB";
  }
  const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  function prettyDate(v) {
    if (!v) return "";
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
    if (!m) return v;
    return parseInt(m[3], 10) + " " + MONTHS[parseInt(m[2], 10) - 1] + " " + m[1];
  }
  function isoFromInvDob(s) { const m = /(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(s || ""); return m ? (m[3] + "-" + String(m[2]).padStart(2, "0") + "-" + String(m[1]).padStart(2, "0")) : ""; }
  function dmyFromIso(s) { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ""); return m ? (m[3] + "/" + m[2] + "/" + m[1]) : (s || ""); }
  function ageFromIso(s) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ""); if (!m) return null;
    const dob = new Date(+m[1], +m[2] - 1, +m[3]); if (isNaN(dob.getTime())) return null;
    const now = new Date(); let a = now.getFullYear() - dob.getFullYear();
    const mo = now.getMonth() - dob.getMonth(); if (mo < 0 || (mo === 0 && now.getDate() < dob.getDate())) a--;
    return a;
  }
  function safe(s) {
    let out = "";
    for (const ch of String(s == null ? "" : s)) {
      const c = ch.charCodeAt(0);
      if (c === 10 || c === 13) { out += " "; continue; }
      out += (c <= 255) ? ch : "?";
    }
    return out;
  }
  const d_ = v => (v == null ? "" : String(v));
  function joinNames(arr) {
    arr = arr.filter(Boolean);
    if (arr.length <= 1) return arr[0] || "";
    if (arr.length === 2) return arr[0] + " and " + arr[1];
    return arr.slice(0, -1).join(", ") + " and " + arr[arr.length - 1];
  }
  function slugOf(s) { return (s || "applicant").replace(/[^A-Za-z0-9]+/g, "_").replace(/^_|_$/g, "").slice(0, 40) || "applicant"; }

  // ===========================================================
  //  INVITATION PDF → text (pdf.js)
  // ===========================================================
  function joinRow(row) {
    row.sort((a, b) => a.x - b.x);
    let out = "", prevEnd = null;
    for (const it of row) {
      if (prevEnd === null) out = it.s;
      else { const gap = it.x - prevEnd; out += (gap > 1.4 ? " " : "") + it.s; }
      prevEnd = it.x + (it.w || 0);
    }
    return out.replace(/\s+/g, " ").trim();
  }
  function buildLinesFromItems(items) {
    const its = items.filter(i => i.s && i.s.trim().length);
    its.sort((a, b) => (b.y - a.y) || (a.x - b.x));
    const lines = []; let cur = [], anchor = null;
    for (const it of its) {
      if (anchor === null) { anchor = it.y; cur = [it]; continue; }
      if (Math.abs(it.y - anchor) <= 3) cur.push(it);
      else { lines.push(joinRow(cur)); cur = [it]; anchor = it.y; }
    }
    if (cur.length) lines.push(joinRow(cur));
    return lines.join("\n");
  }
  async function extractInvitation(bytes) {
    const doc = await pdfjsLib.getDocument({ data: bytes.slice() }).promise;
    let text = "";
    for (let p = 1; p <= doc.numPages; p++) {
      const page = await doc.getPage(p);
      const tc = await page.getTextContent();
      const items = tc.items.filter(i => i.str)
        .map(i => ({ x: i.transform[4], y: i.transform[5], w: i.width || 0, s: i.str }));
      text += buildLinesFromItems(items) + "\n";
    }
    return text;
  }

  // ---------------- parse only needed fields ----------------
  const clean = s => (s == null ? "" : String(s)).replace(/\s+/g, " ").trim();
  function lineVal(region, re) { const m = re.exec(region); return m ? clean(m[1]) : ""; }
  function pName(region) {
    const m = /Surname\s+(.+?)\s+Given\s+name\s+(.+)/i.exec(region);
    if (!m) return "";
    return clean(clean(m[2]) + " " + clean(m[1]));
  }
  function pPassport(region) { const m = /Passport\s*No\.?\s+([A-Z0-9]{4,})/i.exec(region); return m ? m[1].trim() : ""; }
  function pDob(region) { const m = /Date\s*of\s*Birth\s+(\d{1,2}\/\d{1,2}\/\d{4})/i.exec(region); return m ? m[1].trim() : ""; }
  function pContact(region) {
    const m = /Contact\s*Number\s*\(\s*in\s*Native[^\d]*(\d[\d\s\-]{4,})/i.exec(region);
    return m ? m[1].replace(/[\s\-]/g, "").trim() : "";
  }
  function pEmail(region) { const m = /Email\s*Id\s+([^\s]+@[^\s]+)/i.exec(region); return m ? m[1].trim() : ""; }

  function parseAttendants(region) {
    if (!region) return [];
    const parts = region.split(/Sr\s*No\.?\s*\d+/i);
    const chunks = parts.length > 1 ? parts.slice(1) : [region];
    const out = [];
    for (const ch of chunks) {
      const name = pName(ch), passport = pPassport(ch);
      if (name || passport) out.push({ name, passport, dob: pDob(ch), contact: pContact(ch), email: pEmail(ch) });
      if (out.length >= MAX_ATT) break;
    }
    return out;
  }

  function parseInvitation(text) {
    const t = text || "";
    const idx = re => { const m = re.exec(t); return m ? m.index : -1; };
    const iHosp = idx(/Hospital Details/i);
    const iNodal = idx(/Nodal Officer/i);
    const iPat = idx(/Details of the Patient/i);
    const iTreat = idx(/Details of Treatment/i);
    const iAtt = idx(/Details of Attendant/i);

    const slice = (a, b) => (a < 0 ? "" : t.slice(a, (b > a ? b : t.length)));
    const hospR = slice(iHosp, iNodal);
    const patR = slice(iPat, iTreat > iPat ? iTreat : iAtt);
    const treatR = slice(iTreat, iAtt);
    const attR = iAtt >= 0 ? t.slice(iAtt) : "";

    const hospital = { name: lineVal(hospR, /(?:^|\n)\s*Name\s+(.+)/i), address: lineVal(hospR, /(?:^|\n)\s*Address\s+(.+)/i), state: "" };
    const cs = /City\/?[\s]*District\s+(.+?)\s+State\s+(.+)/i.exec(hospR);
    if (cs) hospital.state = clean(cs[2]);
    hospital.full = clean([hospital.address, hospital.state].filter(Boolean).join(", ") + (hospital.address ? ", India" : ""));

    const patient = { name: pName(patR), passport: pPassport(patR), dob: pDob(patR), contact: pContact(patR), email: pEmail(patR) };
    const attendants = parseAttendants(attR);
    const purpose = lineVal(treatR, /Diagnosis\s*\/?[\s]*Proposed\s*Treatment\s+(.+)/i);
    return { hospital, patient, attendants, purpose };
  }

  // ===========================================================
  //  LAYOUT ENGINE
  // ===========================================================
  async function makeContext() {
    const doc = await PDFDocument.create();
    const fontR = await doc.embedFont(StandardFonts.TimesRoman);
    const fontB = await doc.embedFont(StandardFonts.TimesRomanBold);
    const PW = 595.28, PH = 841.89, M = 62, W = PW - M * 2, FS = 11, LH = 15.2;
    const INK = rgb(0.08, 0.08, 0.09), GREY = rgb(0.45, 0.45, 0.45);
    let page = doc.addPage([PW, PH]), y = PH - M;

    function ensure(need) { if (y - need < M) { page = doc.addPage([PW, PH]); y = PH - M; } }
    const wOf = (txt, f, fs) => f.widthOfTextAtSize(txt, fs);

    function wrap(runs, maxW, fs) {
      const words = [];
      for (const r of runs) {
        const f = r.bold ? fontB : fontR;
        for (const p of safe(r.text).split(/(\s+)/)) if (p.length) words.push({ t: p, f, sp: /^\s+$/.test(p) });
      }
      const lines = []; let cur = [], cw = 0;
      const ww = w => wOf(w.t, w.f, fs);
      const trimEnd = () => { while (cur.length && cur[cur.length - 1].sp) { cw -= ww(cur[cur.length - 1]); cur.pop(); } };
      for (const w of words) {
        const x = ww(w);
        if (w.sp) {
          if (!cur.length) continue;
          if (cw + x > maxW) { trimEnd(); lines.push({ segs: cur, w: cw }); cur = []; cw = 0; continue; }
          cur.push(w); cw += x;
        } else {
          if (cw + x > maxW && cur.length) { trimEnd(); lines.push({ segs: cur, w: cw }); cur = []; cw = 0; }
          cur.push(w); cw += x;
        }
      }
      if (cur.length) { trimEnd(); lines.push({ segs: cur, w: cw }); }
      return lines;
    }
    function drawLines(lines, leftX, maxW, opts) {
      const fs = opts.fs || FS, justify = opts.justify;
      for (let i = 0; i < lines.length; i++) {
        const ln = lines[i]; ensure(LH);
        let x = leftX, gap = 0;
        if (justify && i < lines.length - 1) {
          const sp = ln.segs.filter(s => s.sp).length;
          if (sp > 0) gap = (maxW - ln.w) / sp;
        }
        for (const s of ln.segs) {
          page.drawText(s.t, { x, y: y - fs, size: fs, font: s.f, color: INK });
          x += wOf(s.t, s.f, fs) + (s.sp ? gap : 0);
        }
        y -= LH;
      }
    }
    return {
      line(runs, opts) { opts = opts || {}; drawLines(wrap(runs, W, opts.fs || FS), M, W, opts); },
      para(runs, opts) { opts = Object.assign({ justify: true }, opts || {}); drawLines(wrap(runs, W, opts.fs || FS), M, W, opts); this.gap(opts.after == null ? 9 : opts.after); },
      title(text) { ensure(LH + 8); const f = fontB, t = safe(text), tw = wOf(t, f, 15); page.drawText(t, { x: (PW - tw) / 2, y: y - 15, size: 15, font: f, color: INK }); page.drawLine({ start: { x: (PW - tw) / 2, y: y - 17.5 }, end: { x: (PW + tw) / 2, y: y - 17.5 }, thickness: 0.9, color: INK }); y -= LH + 8; },
      subject(text) {
        ensure(LH); const f = fontB, t = safe(text);
        page.drawText(t, { x: M, y: y - FS, size: FS, font: f, color: INK });
        page.drawLine({ start: { x: M, y: y - FS - 1.5 }, end: { x: M + wOf(t, f, FS), y: y - FS - 1.5 }, thickness: 0.8, color: INK });
        y -= LH;
      },
      list(items) {
        const numX = M + 14, textX = M + 36, maxW = W - (textX - M);
        for (let i = 0; i < items.length; i++) {
          ensure(LH);
          page.drawText((i + 1) + ".", { x: numX, y: y - FS, size: FS, font: fontR, color: INK });
          drawLines(wrap(items[i], maxW, FS), textX, maxW, { justify: true });
          this.gap(2);
        }
      },
      fieldBlank(label, w) {
        ensure(LH); const t = safe(label);
        page.drawText(t, { x: M, y: y - FS, size: FS, font: fontB, color: INK });
        const lx = M + wOf(t, fontB, FS) + 6;
        page.drawLine({ start: { x: lx, y: y - FS + 1 }, end: { x: lx + (w || 180), y: y - FS + 1 }, thickness: 0.8, color: GREY });
        y -= LH;
      },
      async image(bytes, fmt, opts) {
        opts = opts || {};
        let img;
        try { img = (fmt === "png") ? await doc.embedPng(bytes) : await doc.embedJpg(bytes); }
        catch (e) { try { img = await doc.embedPng(bytes); } catch (_) { return; } }
        const maxW = opts.maxW || 150, maxH = opts.maxH || 44;
        const s = Math.min(maxW / img.width, maxH / img.height, 1);
        const w = img.width * s, h = img.height * s;
        ensure(h + 2);
        page.drawImage(img, { x: M, y: y - h, width: w, height: h });
        y -= h;
      },
      sigLine(w) { ensure(LH); page.drawLine({ start: { x: M, y: y - 2 }, end: { x: M + (w || 220), y: y - 2 }, thickness: 1, color: INK }); y -= LH; },
      gap(h) { y -= (h || 8); },
      async save() { return await doc.save({ useObjectStreams: true }); }
    };
  }
  const R = t => ({ text: t });
  const B = t => ({ text: t, bold: true });

  // Uses selectedMission for the "To" address block
  function head(c) {
    const m = selectedMission;
    c.line([R("To")]);
    c.line([R(m.officer)]);
    c.line([R(m.line1)]);
    c.line([R(m.line2)]);
  }

  // ---------------- PATIENT letter (0–3 attendants) ----------------
  async function renderPatient(d, sig) {
    const c = await makeContext();
    const atts = (d.attendants || []).filter(a => a.name);
    const n = atts.length;
    const We = n ? "We" : "I", our = n ? "our" : "my";
    const names = joinNames(atts.map(a => a.name));

    head(c);
    c.gap(10); c.subject("Subject: Undertaking for Medical Visa Application."); c.gap(8);
    c.para([R("I, "), B(d.FULL_NAME), R(", holder of Bangladesh Passport No. "), B(d.PASSPORT_NO),
      R(", am applying for a Medical Visa to travel to India for treatment at "), B(d.HOSPITAL_NAME),
      R(", located at "), B(d.HOSPITAL_FULL_ADDRESS), R(".")]);
    c.para([R("I am seeking medical treatment for "), B(d.PURPOSE_OF_TREATMENT),
      R(" as advised by the concerned medical specialists. The purpose of my visit is solely for medical consultation, treatment, and related follow-up procedures at the above-mentioned hospital.")]);

    if (n >= 1) {
      c.para([R("I would also like to request the issuance of " + (n > 1 ? "Medical Attendant Visas" : "a Medical Attendant Visa") + " for my " + (n > 1 ? "attendants" : "attendant") + ":")], { after: 3 });
      if (n === 1) {
        c.line([B("Name: "), R(atts[0].name)]);
        c.line([B("Passport Number: "), R(atts[0].passport)]);
      } else {
        atts.forEach((a, j) => c.line([B("Attendant " + (j + 1) + ": "), R(a.name + " (Passport No. " + a.passport + ")")]));
      }
      c.gap(10);
    } else { c.gap(2); }

    c.para([R("I undertake that:")], { justify: false, after: 4 });
    const items = [[R("All information provided in the visa application and supporting documents is true and correct to the best of my knowledge.")]];
    if (n >= 1) items.push([R("My " + (n > 1 ? "attendants, " : "attendant, ")), B(names), R(", will accompany me only for the purpose of providing necessary assistance during my medical treatment.")]);
    items.push([R(We + " shall abide by all laws, rules, and regulations of India during " + our + " stay.")]);
    items.push([R(We + " shall not engage in any activity other than those permitted under the respective visa " + (n ? "categories" : "category") + ".")]);
    items.push([R(We + " shall bear all expenses related to travel, accommodation, medical treatment, and other associated costs during " + our + " stay in India.")]);
    items.push([R(We + " shall leave India upon completion of the medical treatment and within the validity period of the " + (n ? "visas" : "visa") + " granted.")]);
    c.list(items);
    c.gap(8);
    c.para([R("I respectfully request the " + selectedMission.shortName + " to kindly consider " + (n ? "our visa applications" : "my visa application") +
      " and grant the necessary Medical Visa" + (n ? (n > 1 ? " and Medical Attendant Visas." : " and Medical Attendant Visa.") : "."))], { after: 3 });
    c.para([R("Thank you for your kind consideration.")], { justify: false, after: 14 });
    return signOff(c, d, d.FULL_NAME, d.PASSPORT_NO, sig);
  }

  // ---------------- ATTENDANT letter ----------------
  async function renderAttendant(d, sig, idx) {
    const c = await makeContext();
    const a = (d.attendants || [])[idx] || { name: "", passport: "" };
    head(c);
    c.gap(10); c.subject("Subject: Undertaking for Medical Attendant Visa Application."); c.gap(8);
    c.para([R("I, "), B(a.name), R(", holder of Bangladesh Passport No. "), B(a.passport),
      R(", am applying for a Medical Attendant Visa to accompany my patient "), B(d.FULL_NAME),
      R(", holder of Bangladesh Passport No. "), B(d.PASSPORT_NO),
      R(", who is travelling to India for medical treatment at "), B(d.HOSPITAL_NAME),
      R(", located at "), B(d.HOSPITAL_FULL_ADDRESS), R(".")]);
    c.para([R("The patient is seeking medical treatment for "), B(d.PURPOSE_OF_TREATMENT),
      R(" as advised by the concerned medical specialists. I will be accompanying the patient solely to provide the necessary care and assistance during the medical consultation, treatment, and related follow-up procedures at the above-mentioned hospital.")]);
    c.para([R("Details of the patient I will be accompanying:")], { after: 3 });
    c.line([B("Name: "), R(d.FULL_NAME)]);
    c.line([B("Passport Number: "), R(d.PASSPORT_NO)]); c.gap(10);
    c.para([R("I undertake that:")], { justify: false, after: 4 });
    c.list([
      [R("All information provided in the visa application and supporting documents is true and correct to the best of my knowledge.")],
      [R("I, "), B(a.name), R(", will accompany the patient only for the purpose of providing necessary assistance during the medical treatment.")],
      [R("We shall abide by all laws, rules, and regulations of India during our stay.")],
      [R("We shall not engage in any activity other than those permitted under the respective visa categories.")],
      [R("We shall bear all expenses related to travel, accommodation, medical treatment, and other associated costs during our stay in India.")],
      [R("We shall leave India upon completion of the medical treatment and within the validity period of the visa granted.")]
    ]);
    c.gap(8);
    c.para([R("I respectfully request the " + selectedMission.shortName + " to kindly consider this application and grant the necessary Medical Attendant Visa.")], { after: 3 });
    c.para([R("Thank you for your kind consideration.")], { justify: false, after: 14 });
    return signOff(c, d, a.name, a.passport, sig);
  }

  async function signOff(c, d, signName, signPassport, sig) {
    c.line([R("Yours faithfully,")]);
    if (sig && sig.bytes) { c.gap(8); await c.image(sig.bytes, sig.fmt, { maxW: 190, maxH: 55 }); c.gap(2); }
    else c.gap(28);
    c.sigLine(220);
    c.line([B(signName)]);
    c.line([R("Passport No: " + d_(signPassport))]);
    c.line([R("Date: " + d_(d.DATE_OF_FILLING))]); c.gap(8);
    c.line([B("Contact Number: "), R(d.MOBILE_NUMBER)]);
    return await c.save();
  }

  // ---------------- PARENTAL CONSENT letter ----------------
  async function renderConsent(d) {
    const c = await makeContext();
    c.title("PARENTAL CONSENT LETTER"); c.gap(6);
    c.line([B("Date: "), R(d.date)]); c.gap(8);
    head(c); c.gap(10);
    c.subject("Subject: Consent for Medical Treatment and Travel of Minor Child"); c.gap(8);
    c.para([R("We, "), B("Mr. " + d.father.name), R(" (Father) and "), B("Mrs. " + d.mother.name),
      R(" (Mother), hereby give our full consent and permission for our minor child, "),
      B(d.childName), R(", Passport No. "), B(d.childPass), R(", Date of Birth "), B(d.childDob || "____"),
      R(", to travel to India for medical treatment at "), B(d.hospital), R(", India.")]);
    c.para([R("We have no objection to our child obtaining an Indian Medical Visa and undergoing the required medical treatment in India. We fully understand the purpose of the visit and accept responsibility for all matters related to the child's travel, stay, and treatment.")]);
    c.para([R("We confirm that the information provided is true and correct.")], { after: 14 });

    await consentParty(c, "Father's Details", d.father);
    c.gap(12);
    await consentParty(c, "Mother's Details", d.mother);
    c.gap(14);
    c.line([B("Place: "), R(d.place || "Dhaka, Bangladesh")]);
    return await c.save();
  }
  async function consentParty(c, heading, p) {
    c.line([B(heading)]); c.gap(2);
    c.line([B("Name: "), R(p.name)]);
    c.line([B("Passport No.: "), R(p.pass)]);
    c.line([B("Mobile No.: "), R(p.mobile)]); c.gap(8);
    if (p.sig && p.sig.bytes) {
      c.line([B("Signature:")]); c.gap(3);
      await c.image(p.sig.bytes, p.sig.fmt, { maxW: 190, maxH: 55 }); c.gap(1);
      c.sigLine(210);
    } else {
      c.fieldBlank("Signature:", 210);
    }
  }

  // ---------------- download ----------------
  function download(bytes, name) {
    const blob = new Blob([bytes], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  // ===========================================================
  //  attendant rows (0–3) with DOB
  // ===========================================================
  const attWrap = () => $("attendantRows");
  function attCount() { return attWrap().querySelectorAll(".att-row").length; }
  function renumberAtt() { [...attWrap().querySelectorAll(".att-row")].forEach((r, i) => r.querySelector(".att-n").textContent = (i + 1)); }
  function updateAddBtn() { const full = attCount() >= MAX_ATT; $("addAttBtn").disabled = full; $("addAttBtn").classList.toggle("is-off", full); }
  function clearAttRows() { attWrap().innerHTML = ""; }
  function getAttendants() {
    return [...attWrap().querySelectorAll(".att-row")]
      .map(r => ({ name: (r.querySelector(".att-name").value || "").trim(), passport: (r.querySelector(".att-pass").value || "").trim(), dob: (r.querySelector(".att-dob").value || "").trim() }))
      .filter(a => a.name);
  }
  function makeAttRow(name, pass, dobIso) {
    if (attCount() >= MAX_ATT) { toast("সর্বোচ্চ ৩ জন অ্যাটেনডেন্ট", true); return; }
    const row = document.createElement("div"); row.className = "att-row";
    row.innerHTML =
      '<div class="att-top"><span class="att-tag bn">অ্যাটেনডেন্ট <span class="att-n"></span></span>' +
      '<button type="button" class="att-del" title="মুছুন">✕</button></div>' +
      '<input class="att-name" placeholder="পূর্ণ নাম (যেমন: MST RUMA KHATUN)">' +
      '<div class="att-sub">' +
      '<input class="att-pass" placeholder="পাসপোর্ট (EB0654321)">' +
      '<input type="date" class="att-dob" title="জন্মতারিখ"></div>';
    attWrap().appendChild(row);
    row.querySelector(".att-name").value = name || "";
    row.querySelector(".att-pass").value = pass || "";
    row.querySelector(".att-dob").value = dobIso || "";
    row.querySelector(".att-del").addEventListener("click", () => { row.remove(); renumberAtt(); updateAddBtn(); rebuildTargetSelector(); saveStore(); });
    row.querySelector(".att-name").addEventListener("input", () => { rebuildTargetSelector(); saveStore(); });
    row.querySelector(".att-pass").addEventListener("input", saveStore);
    row.querySelector(".att-dob").addEventListener("input", saveStore);
    renumberAtt(); updateAddBtn(); rebuildTargetSelector();
  }

  // ---------------- target selector ----------------
  function rebuildTargetSelector() {
    const sel = $("targetSel"); if (!sel) return;
    const atts = getAttendants();
    let html = '<button type="button" class="tg-btn bn" data-role="patient">🩺 রোগী</button>';
    atts.forEach((a, j) => { html += '<button type="button" class="tg-btn bn" data-role="attendant" data-idx="' + j + '">🤝 অ্যাটেনডেন্ট ' + (j + 1) + '</button>'; });
    sel.innerHTML = html;
    sel.querySelectorAll(".tg-btn").forEach(b => b.addEventListener("click", () => setTarget({ role: b.dataset.role, idx: b.dataset.idx != null ? +b.dataset.idx : null })));
    if (target.role === "attendant" && (atts.length === 0 || target.idx >= atts.length)) target = { role: "patient", idx: null };
    applyTargetActive();
  }
  function applyTargetActive() {
    const sel = $("targetSel"); if (!sel) return;
    sel.querySelectorAll(".tg-btn").forEach(b => {
      const r = b.dataset.role, i = b.dataset.idx != null ? +b.dataset.idx : null;
      b.classList.toggle("on", r === target.role && (r !== "attendant" || i === target.idx));
    });
    $("modePill").textContent = target.role === "attendant" ? ("অ্যাটেনডেন্ট " + (target.idx + 1)) : "রোগী";
  }
  function setTarget(t) { target = t; applyTargetActive(); }

  function personData(t) {
    if (t.role === "attendant") { const a = getAttendants()[t.idx] || {}; return { name: a.name || "", passport: a.passport || "", dobIso: a.dob || "" }; }
    return { name: ($("FULL_NAME").value || "").trim(), passport: ($("PASSPORT_NO").value || "").trim(), dobIso: ($("DOB_PATIENT").value || "").trim() };
  }

  // ---------------- form <-> storage ----------------
  function set(id, v) { const el = $(id); if (el) el.value = v == null ? "" : v; }
  function collect() {
    const d = {};
    for (const f of FIELDS) {
      let v = ($(f).value || "").trim();
      // Always use today's date when generating — never use stored old date
      if (f === "DATE_OF_FILLING") v = prettyDate(new Date().toISOString().slice(0, 10));
      d[f] = v;
    }
    d.attendants = getAttendants();
    return d;
  }
  function saveStore() {
    const o = { f: {}, dobP: $("DOB_PATIENT").value || "", atts: getAttendants() };
    for (const f of FIELDS) o.f[f] = $(f).value || "";
    try { localStorage.setItem(STORE_KEY, JSON.stringify(o)); } catch (e) {}
  }
  function loadStore() {
    try {
      const o = JSON.parse(localStorage.getItem(STORE_KEY) || "{}");
      if (o.f) for (const f of FIELDS) if (o.f[f] != null) $(f).value = o.f[f];
      if (o.dobP != null) $("DOB_PATIENT").value = o.dobP;
      clearAttRows();
      (o.atts || []).slice(0, MAX_ATT).forEach(a => makeAttRow(a.name, a.passport, a.dob));
    } catch (e) {}
  }
  function validate() {
    const lbl = { FULL_NAME: "রোগীর নাম", PASSPORT_NO: "রোগীর পাসপোর্ট", HOSPITAL_NAME: "হাসপাতালের নাম", HOSPITAL_FULL_ADDRESS: "হাসপাতালের ঠিকানা", PURPOSE_OF_TREATMENT: "চিকিৎসার কারণ", DATE_OF_FILLING: "তারিখ", MOBILE_NUMBER: "মোবাইল নম্বর" };
    const miss = [];
    for (const f of REQUIRED) if (!($(f).value || "").trim()) miss.push(lbl[f] || f);
    [...attWrap().querySelectorAll(".att-row")].forEach((r, i) => {
      const nm = (r.querySelector(".att-name").value || "").trim(), ps = (r.querySelector(".att-pass").value || "").trim();
      if (nm && !ps) miss.push("অ্যাটেনডেন্ট " + (i + 1) + " পাসপোর্ট");
    });
    if (target.role === "attendant") {
      const a = getAttendants()[target.idx];
      if (!a || !a.name || !a.passport) miss.push("নির্বাচিত অ্যাটেনডেন্টের নাম/পাসপোর্ট");
    }
    return miss;
  }

  function applyExtractAll(P) {
    set("FULL_NAME", P.patient.name);
    set("PASSPORT_NO", P.patient.passport);
    set("DOB_PATIENT", isoFromInvDob(P.patient.dob));
    set("HOSPITAL_NAME", P.hospital.name);
    set("HOSPITAL_FULL_ADDRESS", P.hospital.full);
    set("PURPOSE_OF_TREATMENT", P.purpose);
    const firstAttContact = (P.attendants[0] && P.attendants[0].contact) || "";
    set("MOBILE_NUMBER", P.patient.contact || firstAttContact || "");
    if (!$("DATE_OF_FILLING").value) $("DATE_OF_FILLING").value = new Date().toISOString().slice(0, 10);
    clearAttRows();
    (P.attendants || []).slice(0, MAX_ATT).forEach(a => makeAttRow(a.name, a.passport, isoFromInvDob(a.dob)));
    rebuildTargetSelector();
    $("extractBanner").classList.add("show");
    saveStore();
  }

  // ===========================================================
  //  SIGNATURE EDITOR
  // ===========================================================
  let cropBox  = null;
  let cropDrag = null;
  const HSIZE  = 10;   // resize handle half-size
  const MINCROP = 20;

  // ── open ──
  function openSigFile(slot, file) {
    if (!/^image\//.test(file.type)) { toast("ছবি দিন (PNG/JPG)", true); return; }
    activeSlot = slot;
    const s = SIG[slot];
    const img = new Image();
    img.onload = () => {
      s.source = img; s.crop = null; s.rot = 0;
      s.adjust = { bright:0, contrast:0, white:0 };
      sigBackup = s.data; openSigEditor();
    };
    img.onerror = () => toast("ছবি পড়া যায়নি", true);
    img.src = URL.createObjectURL(file);
  }
  function editSig(slot) { activeSlot = slot; if (SIG[slot].source) { sigBackup = SIG[slot].data; openSigEditor(); } }

  function openSigEditor() {
    const s = SIG[activeSlot]; if (!s.source) return;
    $("sigEditWho").textContent = activeSlot==="father"?"বাবার স্বাক্ষর":activeSlot==="mother"?"মায়ের স্বাক্ষর":"আবেদনকারীর স্বাক্ষর";
    $("adjBright").value   = s.adjust.bright;
    $("adjContrast").value = s.adjust.contrast;
    $("adjWhite").value    = s.adjust.white;
    $("adjRot").value      = s.rot || 0;
    $("valBright").textContent   = s.adjust.bright;
    $("valContrast").textContent = s.adjust.contrast;
    $("valWhite").textContent    = s.adjust.white;
    $("valRot").textContent      = (s.rot||0) + "°";
    cropBox = null;
    renderSigEditor();
    $("sigEditModal").classList.add("show");
  }
  function closeSigEditor() { $("sigEditModal").classList.remove("show"); cropDrag = null; }

  // ── draw rotated image ──
  function drawRotated(ctx, src, crop, deg, w, h) {
    const rad = deg * Math.PI / 180;
    const ac = Math.abs(Math.cos(rad)), as = Math.abs(Math.sin(rad));
    const sc = Math.min(w/(crop.sw*ac+crop.sh*as), h/(crop.sw*as+crop.sh*ac), 1);
    ctx.save();
    ctx.translate(w/2, h/2);
    ctx.rotate(rad);
    ctx.drawImage(src, crop.sx, crop.sy, crop.sw, crop.sh,
      -crop.sw*sc/2, -crop.sh*sc/2, crop.sw*sc, crop.sh*sc);
    ctx.restore();
  }

  // ── BG flood-fill remove ──
  function runBgRemove(ctx, w, h) {
    const id = ctx.getImageData(0,0,w,h), px = id.data;
    function samp(cx,cy){
      let r=0,g=0,b=0,n=0;
      for(let dy=-2;dy<=2;dy++) for(let dx=-2;dx<=2;dx++){
        const x=cx+dx,y=cy+dy; if(x<0||x>=w||y<0||y>=h) continue;
        const i=(y*w+x)*4; if(px[i+3]<10) continue;
        r+=px[i];g+=px[i+1];b+=px[i+2];n++;
      } return n?[r/n|0,g/n|0,b/n|0]:null;
    }
    const cs=[samp(2,2),samp(w-3,2),samp(2,h-3),samp(w-3,h-3)].filter(Boolean);
    if(!cs.length) return;
    const BR=cs.reduce((s,c)=>s+c[0],0)/cs.length|0;
    const BG=cs.reduce((s,c)=>s+c[1],0)/cs.length|0;
    const BB=cs.reduce((s,c)=>s+c[2],0)/cs.length|0;
    const TOL=50, vis=new Uint8Array(w*h), q=[];
    function enq(x,y){if(x<0||x>=w||y<0||y>=h)return;const i=y*w+x;if(vis[i])return;vis[i]=1;q.push(i);}
    for(let x=0;x<w;x++){enq(x,0);enq(x,h-1);}
    for(let y=1;y<h-1;y++){enq(0,y);enq(w-1,y);}
    let qi=0;
    while(qi<q.length){
      const idx=q[qi++],pi=idx*4; if(px[pi+3]<10) continue;
      if(Math.abs(px[pi]-BR)>TOL||Math.abs(px[pi+1]-BG)>TOL||Math.abs(px[pi+2]-BB)>TOL) continue;
      px[pi+3]=0;
      const x=idx%w,y=idx/w|0;enq(x+1,y);enq(x-1,y);enq(x,y+1);enq(x,y-1);
    }
    ctx.putImageData(id,0,0);
  }

  // ── render ──
  function renderSigEditor() {
    const s = SIG[activeSlot], src = s.source; if(!src) return;
    const sw0=src.naturalWidth||src.width, sh0=src.naturalHeight||src.height;
    const crop = s.crop || {sx:0,sy:0,sw:sw0,sh:sh0};
    const deg  = +(s.rot||0);
    const maxW = Math.min(500, window.innerWidth-80);
    const scale = Math.min(maxW/crop.sw, 340/crop.sh, 1);
    const W = Math.max(1, Math.round(crop.sw*scale));
    const H = Math.max(1, Math.round(crop.sh*scale));
    const cv=$("sigCanvas");
    // Only resize canvas if dimensions changed — prevents cropBox reset on every slider move
    if(cv.width!==W || cv.height!==H) {
      cv.width=W; cv.height=H;
      // reset cropBox to full frame when canvas size changes
      cropBox = {x:0, y:0, w:W, h:H};
    }
    const ctx=cv.getContext("2d");
    ctx.clearRect(0,0,W,H);
    ctx.filter="brightness("+(100+(+s.adjust.bright))+"%) contrast("+(100+(+s.adjust.contrast))+"%)";
    if(deg!==0) drawRotated(ctx,src,crop,deg,W,H);
    else ctx.drawImage(src,crop.sx,crop.sy,crop.sw,crop.sh,0,0,W,H);
    ctx.filter="none";
    if(+s.adjust.white>0){
      const id=ctx.getImageData(0,0,W,H),px=id.data,th=255-(+s.adjust.white/100)*150;
      for(let i=0;i<px.length;i+=4){const l=0.299*px[i]+0.587*px[i+1]+0.114*px[i+2];if(l>=th)px[i+3]=0;}
      ctx.putImageData(id,0,0);
    }
    // init cropBox full-frame if null
    if(!cropBox) cropBox={x:0,y:0,w:W,h:H};
    // clamp
    cropBox.w=Math.max(MINCROP,Math.min(cropBox.w,W-cropBox.x));
    cropBox.h=Math.max(MINCROP,Math.min(cropBox.h,H-cropBox.y));
    cropBox.x=Math.max(0,Math.min(cropBox.x,W-cropBox.w));
    cropBox.y=Math.max(0,Math.min(cropBox.y,H-cropBox.h));
    drawCropOverlay(ctx,cropBox,W,H);
    $("valRot").textContent=Math.round(deg)+"°";
  }

  // ── draw crop overlay ──
  function drawCropOverlay(ctx, cb, W, H) {
    ctx.save();
    ctx.fillStyle="rgba(0,0,0,0.45)";
    ctx.fillRect(0,0,W,cb.y);
    ctx.fillRect(0,cb.y,cb.x,cb.h);
    ctx.fillRect(cb.x+cb.w,cb.y,W-cb.x-cb.w,cb.h);
    ctx.fillRect(0,cb.y+cb.h,W,H-cb.y-cb.h);
    ctx.strokeStyle="#13b87e"; ctx.lineWidth=2; ctx.setLineDash([]);
    ctx.strokeRect(cb.x,cb.y,cb.w,cb.h);
    ctx.strokeStyle="rgba(255,255,255,0.22)"; ctx.lineWidth=1;
    ctx.beginPath();
    [1/3,2/3].forEach(f=>{
      ctx.moveTo(cb.x+cb.w*f,cb.y); ctx.lineTo(cb.x+cb.w*f,cb.y+cb.h);
      ctx.moveTo(cb.x,cb.y+cb.h*f); ctx.lineTo(cb.x+cb.w,cb.y+cb.h*f);
    });
    ctx.stroke();
    const hs=HSIZE;
    [{x:cb.x,y:cb.y},{x:cb.x+cb.w/2,y:cb.y},{x:cb.x+cb.w,y:cb.y},
     {x:cb.x+cb.w,y:cb.y+cb.h/2},{x:cb.x+cb.w,y:cb.y+cb.h},
     {x:cb.x+cb.w/2,y:cb.y+cb.h},{x:cb.x,y:cb.y+cb.h},{x:cb.x,y:cb.y+cb.h/2}
    ].forEach(p=>{
      ctx.fillStyle="#fff"; ctx.strokeStyle="#13b87e"; ctx.lineWidth=1.5;
      ctx.fillRect(p.x-hs/2,p.y-hs/2,hs,hs);
      ctx.strokeRect(p.x-hs/2,p.y-hs/2,hs,hs);
    });
    ctx.restore();
  }

  // ── canvas coords ──
  function cvXY(e) {
    const cv=$("sigCanvas"), r=cv.getBoundingClientRect();
    const sx=cv.width/r.width, sy=cv.height/r.height;
    const ex=(e.touches?e.touches[0].clientX:e.clientX)-r.left;
    const ey=(e.touches?e.touches[0].clientY:e.clientY)-r.top;
    return {x:ex*sx, y:ey*sy};
  }

  // ── hit test ──
  function getHandle(p, cb) {
    const hs=HSIZE+5, hh=hs/2;
    const pts=[
      {t:'nw',x:cb.x,y:cb.y},{t:'n',x:cb.x+cb.w/2,y:cb.y},
      {t:'ne',x:cb.x+cb.w,y:cb.y},{t:'e',x:cb.x+cb.w,y:cb.y+cb.h/2},
      {t:'se',x:cb.x+cb.w,y:cb.y+cb.h},{t:'s',x:cb.x+cb.w/2,y:cb.y+cb.h},
      {t:'sw',x:cb.x,y:cb.y+cb.h},{t:'w',x:cb.x,y:cb.y+cb.h/2},
    ];
    for(const p2 of pts) if(Math.abs(p.x-p2.x)<=hh&&Math.abs(p.y-p2.y)<=hh) return p2.t;
    if(p.x>cb.x&&p.x<cb.x+cb.w&&p.y>cb.y&&p.y<cb.y+cb.h) return 'move';
    return null;
  }

  // ── mouse/touch events ──
  function cropMouseDown(e) {
    e.preventDefault();
    const p=cvXY(e); if(!cropBox) return;
    const t=getHandle(p,cropBox); if(!t) return;
    cropDrag={t,ox:p.x,oy:p.y,bx:cropBox.x,by:cropBox.y,bw:cropBox.w,bh:cropBox.h};
  }
  function cropMouseMove(e) {
    if(!cropDrag||!cropBox) return;
    e.preventDefault();
    const cv=$("sigCanvas");
    const p=cvXY(e);
    const dx=p.x-cropDrag.ox, dy=p.y-cropDrag.oy;
    let {bx,by,bw,bh}=cropDrag;
    let nx=bx,ny=by,nw=bw,nh=bh;
    const t=cropDrag.t;
    if(t==='move'){nx=bx+dx;ny=by+dy;}
    if(t==='nw'||t==='w'||t==='sw'){nx=bx+dx;nw=bw-dx;}
    if(t==='ne'||t==='e'||t==='se'){nw=bw+dx;}
    if(t==='nw'||t==='n'||t==='ne'){ny=by+dy;nh=bh-dy;}
    if(t==='sw'||t==='s'||t==='se'){nh=bh+dy;}
    if(nw<MINCROP){if(t.includes('w'))nx=bx+bw-MINCROP;nw=MINCROP;}
    if(nh<MINCROP){if(t.includes('n'))ny=by+bh-MINCROP;nh=MINCROP;}
    if(nx<0){if(t==='move'||t.includes('w'))nw+=nx;nx=0;}
    if(ny<0){if(t==='move'||t.includes('n'))nh+=ny;ny=0;}
    if(nx+nw>cv.width)nw=cv.width-nx;
    if(ny+nh>cv.height)nh=cv.height-ny;
    cropBox={x:Math.round(nx),y:Math.round(ny),w:Math.round(nw),h:Math.round(nh)};
    renderSigEditor();
  }
  function cropMouseUp(){cropDrag=null;}

  // ── apply crop ──
  function applyCrop() {
    if(!cropBox||cropBox.w<MINCROP||cropBox.h<MINCROP){toast("ক্রপ বক্স ঠিক করুন",true);return;}
    const s=SIG[activeSlot],src=s.source;
    const sw0=src.naturalWidth||src.width,sh0=src.naturalHeight||src.height;
    const existing=s.crop||{sx:0,sy:0,sw:sw0,sh:sh0};
    const cv=$("sigCanvas");
    const scX=existing.sw/cv.width, scY=existing.sh/cv.height;
    s.crop={
      sx:existing.sx+cropBox.x*scX,
      sy:existing.sy+cropBox.y*scY,
      sw:cropBox.w*scX,
      sh:cropBox.h*scY
    };
    s.rot=0;
    $("adjRot").value=0; $("valRot").textContent="0°";
    // Force full-frame: set cropBox=null THEN let renderSigEditor handle it
    // BUT we must also force cv resize — set cropBox directly after render
    cropBox=null;
    renderSigEditor();
    // renderSigEditor already sets cropBox to full frame above
    toast("ক্রপ প্রয়োগ হয়েছে ✓");
  }

  // ── bg remove ──
  function applyBgRemove() {
    const cv=$("sigCanvas"),ctx=cv.getContext("2d");
    runBgRemove(ctx,cv.width,cv.height);
    const du=cv.toDataURL("image/png");
    const img=new Image();
    img.onload=()=>{
      SIG[activeSlot].source=img;
      SIG[activeSlot].crop=null;
      SIG[activeSlot].rot=0;
      $("adjRot").value=0; $("valRot").textContent="0°";
      cropBox=null;
      renderSigEditor();
    };
    img.src=du;
    toast("BG রিমুভ হয়েছে ✓");
  }

  function resetCrop(){SIG[activeSlot].crop=null;SIG[activeSlot].rot=0;$("adjRot").value=0;$("valRot").textContent="0°";cropBox=null;renderSigEditor();}
  function resetAdjust(){
    SIG[activeSlot].adjust={bright:0,contrast:0,white:0};
    $("adjBright").value=0;$("adjContrast").value=0;$("adjWhite").value=0;
    $("valBright").textContent="0";$("valContrast").textContent="0";$("valWhite").textContent="0";
    renderSigEditor();
  }

  function sigEditDone() {
    const s=SIG[activeSlot],src=s.source; if(!src) return;
    const sw0=src.naturalWidth||src.width,sh0=src.naturalHeight||src.height;
    const crop=s.crop||{sx:0,sy:0,sw:sw0,sh:sh0};
    const deg=+(s.rot||0);
    const maxW=Math.min(500,window.innerWidth-80);
    const scale=Math.min(maxW/crop.sw,340/crop.sh,1);
    const W=Math.max(1,Math.round(crop.sw*scale));
    const H=Math.max(1,Math.round(crop.sh*scale));
    const cv=$("sigCanvas"); cv.width=W; cv.height=H;
    const ctx=cv.getContext("2d");
    ctx.clearRect(0,0,W,H);
    ctx.filter="brightness("+(100+(+s.adjust.bright))+"%) contrast("+(100+(+s.adjust.contrast))+"%)";
    if(deg!==0) drawRotated(ctx,src,crop,deg,W,H);
    else ctx.drawImage(src,crop.sx,crop.sy,crop.sw,crop.sh,0,0,W,H);
    ctx.filter="none";
    if(+s.adjust.white>0){
      const id=ctx.getImageData(0,0,W,H),px=id.data,th=255-(+s.adjust.white/100)*150;
      for(let i=0;i<px.length;i+=4){const l=0.299*px[i]+0.587*px[i+1]+0.114*px[i+2];if(l>=th)px[i+3]=0;}
      ctx.putImageData(id,0,0);
    }
    const du=cv.toDataURL("image/png");
    const b64=du.split(",")[1],bin=atob(b64),arr=new Uint8Array(bin.length);
    for(let i=0;i<bin.length;i++) arr[i]=bin.charCodeAt(i);
    SIG[activeSlot].data={bytes:arr,fmt:"png",dataUrl:du};
    cropBox=null; cropDrag=null;
    reflectSignature(activeSlot); closeSigEditor(); toast("স্বাক্ষর প্রস্তুত ✓");
  }
  function sigEditCancel() { SIG[activeSlot].data = sigBackup || null; cropBox = null; cropDrag = null; closeSigEditor(); reflectSignature(activeSlot); }
  function clearSig(slot) { SIG[slot].data = null; SIG[slot].source = null; SIG[slot].crop = null; reflectSignature(slot); }
  function reflectSignature(slot) {
    const ui = SLOT_UI[slot]; if (!ui) return;
    const have = !!SIG[slot].data;
    const wrap = $(ui.wrap), prev = $(ui.prev), im = $(ui.img);
    if (wrap) wrap.classList.toggle("hide", have);
    if (prev) prev.classList.toggle("hide", !have);
    if (have && im) im.src = SIG[slot].data.dataUrl;
  }
  function reflectAllSignatures() { Object.keys(SLOT_UI).forEach(reflectSignature); }
  function resetAllSignatures() { Object.keys(SIG).forEach(k => { SIG[k] = newSlot(); }); }

  function setSlotFromDataUrl(slot, dataUrl) {
    const comma = dataUrl.indexOf(",");
    const b64 = dataUrl.slice(comma + 1), bin = atob(b64), arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    const fmt = /^data:image\/png/i.test(dataUrl) ? "png" : "jpg";
    const s = SIG[slot];
    s.data = { bytes: arr, fmt, dataUrl };
    s.crop = null; s.adjust = { bright: 0, contrast: 0, white: 0 };
    const img = new Image();
    img.onload = () => { s.source = img; };
    img.src = dataUrl;
    reflectSignature(slot);
  }

  // ===========================================================
  //  REMOTE UPLOAD (phone -> this computer) via relay.php
  // ===========================================================
  let rTimer = null, rToken = null, rSlot = null, rErrs = 0, rStarted = 0;
  const SLOT_LABEL = { applicant: "আবেদনকারীর স্বাক্ষর", father: "বাবার স্বাক্ষর", mother: "মায়ের স্বাক্ষর" };
  function randToken() {
    let t = "ts";
    const a = "abcdefghijklmnopqrstuvwxyz0123456789";
    const rnd = (window.crypto && crypto.getRandomValues) ? crypto.getRandomValues(new Uint32Array(22)) : null;
    for (let i = 0; i < 22; i++) t += a[(rnd ? rnd[i] : Math.floor(Math.random() * 1e9)) % a.length];
    return t;
  }
  function baseDir() { return location.origin + location.pathname.replace(/[^/]*$/, ""); }
  function relayUrl() { return baseDir() + "relay.php"; }
  function paintQR(url) {
    const box = $("qrBox"); box.innerHTML = "";
    try {
      if (typeof qrcode === "function") { const q = qrcode(0, "M"); q.addData(url); q.make(); box.innerHTML = q.createImgTag(5, 8); }
      else box.textContent = "QR তৈরি করা যায়নি — নিচের লিংকটি ফোনে খুলুন।";
    } catch (e) { box.textContent = "QR তৈরি করা যায়নি — নিচের লিংকটি ফোনে খুলুন।"; }
  }
  function setQrStatus(txt) { const s = $("qrStatus"), t = $("qrStatusTxt"); if (s) s.classList.remove("hide"); if (t) t.textContent = txt; }
  function qrFail(m) { const e = $("qrErr"); if (e) { e.textContent = m; e.classList.remove("hide"); } $("qrStatus").classList.add("hide"); }

  async function startRemote(slot) {
    stopRemote();
    rSlot = slot; rToken = randToken(); rErrs = 0; rStarted = Date.now();
    const url = baseDir() + "capture.html?t=" + rToken + "&who=" + slot;
    try {
      const p = await fetch(relayUrl() + "?ping=1&_=" + Date.now(), { cache: "no-store" });
      const pj = await p.json();
      if (!pj || !pj.ok) { toast("relay.php সাড়া দিচ্ছে না", true); return; }
    } catch(e) { console.warn("relay ping failed:", e); }
    $("qrTitle").textContent = "📱 মোবাইল ব্যবহার করে আপলোড করুন";
    $("qrLead").innerHTML = "<b>" + (SLOT_LABEL[slot] || "স্বাক্ষর") + "</b> — নিচের QR কোডটিে স্ক্যান করুন। ফোনে <b>ব্রাউজ বা ক্যামেরা</b> অপশন ব্যবহার করে ছবি দিলে কয়েক সেকেন্ডে সেটি <b>এই কম্পিউটারের স্বাক্ষর ঘরে</b> বসে যাবে।";
    $("qrErr").classList.add("hide");
    $("qrUrl").textContent = url;
    paintQR(url);
    setQrStatus("✓ প্রস্তুত — ফোন দিয়ে QR স্ক্যান করুন");
    $("qrModal").classList.add("show");
    pollRemote();
  }
  function pollRemote() {
    rTimer = setTimeout(async () => {
      if (!rToken) return;
      if (Date.now() - rStarted > 300000) { qrFail("সময় শেষ — আবার \"কিউআর কোডে\" চাপুন।"); return; }
      try {
        const r = await fetch(relayUrl() + "?get=" + rToken + "&_=" + Date.now(), { cache: "no-store" });
        if (r.status === 404) { qrFail("relay.php সার্ভারে পাওয়া যায়নি — সব ফাইল সাইটে আপলোড করেছেন কিনা দেখুন।"); return; }
        const j = await r.json();
        if (j && j.ok && j.image) { onRemoteImage(rSlot, j.image); return; }
        rErrs = 0;
      } catch (e) {
        rErrs++;
        if (rErrs >= 8) { qrFail("সার্ভারের সাথে সংযোগ পাওয়া যাচ্ছে না — ইন্টারনেট/সাইট দেখুন।"); return; }
      }
      pollRemote();
    }, 2000);
  }
  function onRemoteImage(slot, dataUrl) {
    stopRemote();
    setSlotFromDataUrl(slot, dataUrl);
    closeQR();
    toast("ফোন থেকে ছবি এসেছে ✓ — চাইলে ✎ এডিট করে ক্রপ করুন");
  }
  function stopRemote() { if (rTimer) { clearTimeout(rTimer); rTimer = null; } rToken = null; }

  // ===========================================================
  //  DIRECT CAMERA
  // ===========================================================
  let dcStream = null, dcSlot = null, dcFacing = 'environment';

  function openDirectCam(slot) {
    dcSlot = slot;
    dcFacing = 'environment';
    const labels = { applicant: 'আবেদনকারীর স্বাক্ষর', father: 'বাবার স্বাক্ষর', mother: 'মায়ের স্বাক্ষর' };
    $('dcWho').textContent = labels[slot] || 'স্বাক্ষর';
    $('dcModal').classList.add('show');
    $('dcSnapBtn').classList.remove('hide');
    $('dcPreview').classList.add('hide');
    $('dcVideo').classList.remove('hide');
    $('dcErr').classList.add('hide');
    $('dcSendBtn').classList.add('hide');
    $('dcRetakeBtn').classList.add('hide');
    startDcCam();
  }

  async function startDcCam() {
    stopDcCam();
    $('dcErr').classList.add('hide');
    if (location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
      showDcErr('ক্যামেরা ব্যবহারের জন্য HTTPS সংযোগ দরকার। সাইটটি https:// দিয়ে খুলুন।');
      return;
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      showDcErr('এই ব্রাউজারে ক্যামেরা সাপোর্ট নেই। Chrome বা Firefox ব্যবহার করুন।');
      return;
    }
    const constraints = [
      { video: { facingMode: { ideal: dcFacing }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false },
      { video: { facingMode: dcFacing }, audio: false },
      { video: true, audio: false }
    ];
    let lastErr = null;
    for (const con of constraints) {
      try { dcStream = await navigator.mediaDevices.getUserMedia(con); break; }
      catch(e) { lastErr = e; dcStream = null; }
    }
    if (!dcStream) {
      const n = lastErr && lastErr.name;
      let msg = 'ক্যামেরা চালু হয়নি: ' + (lastErr && lastErr.message || 'অজানা সমস্যা');
      if (n === 'NotAllowedError' || n === 'SecurityError' || n === 'PermissionDeniedError')
        msg = 'ক্যামেরার অনুমতি দিন।\n\nব্রাউজারের address bar এ ক্যামেরা icon এ ক্লিক করে "Allow" করুন, তারপর আবার চেষ্টা করুন।';
      else if (n === 'NotFoundError' || n === 'DevicesNotFoundError')
        msg = 'কোনো ক্যামেরা পাওয়া যায়নি। ডিভাইসে ক্যামেরা আছে কিনা দেখুন।';
      else if (n === 'NotReadableError' || n === 'TrackStartError')
        msg = 'ক্যামেরা অন্য অ্যাপ ব্যবহার করছে। সেই অ্যাপ বন্ধ করে আবার চেষ্টা করুন।';
      showDcErr(msg);
      return;
    }
    try {
      const v = $('dcVideo');
      v.srcObject = dcStream;
      v.onloadedmetadata = () => v.play().catch(() => {});
      $('dcVideo').classList.remove('hide');
      $('dcPreview').classList.add('hide');
    } catch(e) { showDcErr('ভিডিও চালু করা যায়নি: ' + e.message); }
  }

  function stopDcCam() {
    if (dcStream) { dcStream.getTracks().forEach(t => t.stop()); dcStream = null; }
    $('dcVideo').srcObject = null;
  }
  function showDcErr(msg) { stopDcCam(); $('dcErr').textContent = msg; $('dcErr').classList.remove('hide'); }

  function snapDc() {
    const v = $('dcVideo');
    if (!dcStream || !v.videoWidth) { showDcErr('ক্যামেরা এখনো প্রস্তুত নয়।'); return; }
    const cv = document.createElement('canvas');
    cv.width = v.videoWidth; cv.height = v.videoHeight;
    cv.getContext('2d').drawImage(v, 0, 0);
    stopDcCam();
    const dataUrl = cv.toDataURL('image/jpeg', 0.92);
    const img = new Image();
    img.onload = () => {
      const s = Math.min(1600 / Math.max(img.naturalWidth, img.naturalHeight), 1);
      const oc = document.createElement('canvas');
      oc.width = Math.round(img.naturalWidth * s); oc.height = Math.round(img.naturalHeight * s);
      oc.getContext('2d').drawImage(img, 0, 0, oc.width, oc.height);
      const small = oc.toDataURL('image/jpeg', 0.88);
      $('dcPreview').src = small;
      $('dcVideo').classList.add('hide');
      $('dcPreview').classList.remove('hide');
      $('dcSnapBtn').classList.add('hide');
      $('dcSendBtn').classList.remove('hide');
      $('dcRetakeBtn').classList.remove('hide');
      $('dcSendBtn')._dataUrl = small;
    };
    img.src = dataUrl;
  }

  function useDcPhoto() {
    const dataUrl = $('dcSendBtn')._dataUrl;
    if (!dataUrl) return;
    closeDcCam();
    setSlotFromDataUrl(dcSlot, dataUrl);
    toast('ক্যামেরা থেকে ছবি নেওয়া হয়েছে ✓ — চাইলে ✎ এডিট করুন');
  }

  function closeDcCam() { stopDcCam(); $('dcModal').classList.remove('show'); }

  function openFullToolQR() {
    stopRemote();
    const url = baseDir() + "index.html";
    $("qrTitle").textContent = "📱 ফোনে পুরো টুল খুলুন";
    $("qrLead").innerHTML = "QR কোডটি ফোন দিয়ে স্ক্যান করলে এই টুলটি ফোনে খুলবে — সেখানেই তথ্য দিয়ে, ছবি দিয়ে PDF ডাউনলোড করতে পারবেন।";
    $("qrUrl").textContent = url;
    $("qrErr").classList.add("hide");
    $("qrStatus").classList.add("hide");
    paintQR(url);
    $("qrModal").classList.add("show");
  }
  function closeQR() { stopRemote(); $("qrModal").classList.remove("show"); }
  function copyQRUrl() {
    const u = $("qrUrl").textContent || "";
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(u).then(() => toast("লিংক কপি হয়েছে ✓"), () => toast("কপি করা গেল না", true));
    else toast("কপি সাপোর্ট নেই — হাতে কপি করুন", true);
  }


  // ── Ensure PDF is between MIN and MAX size ──
  //  Small PDFs are padded via a trailing valid PDF comment appended
  //  AFTER %%EOF. Anything after the final %%EOF is ignored by every
  //  PDF reader, so the document stays 100% valid and still opens.
  async function ensurePdfSize(bytes) {
    if (bytes.length >= MIN_PDF_SIZE && bytes.length <= MAX_PDF_SIZE) return bytes;

    if (bytes.length > MAX_PDF_SIZE) {
      toast("PDF আকার বড় (" + fmtSize(bytes.length) + ") — স্বাক্ষর ছোট করুন", true);
      return bytes;
    }

    // bytes < 10KB → append padding AFTER the last %%EOF (safe, ignored by readers)
    const needed = MIN_PDF_SIZE - bytes.length + 256;
    // build a comment block: newline + "%" + filler bytes
    let pad = "\n% MVU padding ";
    while (pad.length < needed) pad += "0123456789ABCDEF";
    // convert to bytes (latin1-safe)
    const padBytes = new Uint8Array(pad.length);
    for (let i = 0; i < pad.length; i++) padBytes[i] = pad.charCodeAt(i) & 0xff;
    // concatenate original bytes + padding (append at very end)
    const out = new Uint8Array(bytes.length + padBytes.length);
    out.set(bytes, 0);
    out.set(padBytes, bytes.length);
    return out;
  }

  // ---------------- generate undertaking ----------------
  async function generate() {
    const miss = validate();
    if (miss.length) { toast("পূরণ করুন: " + miss.slice(0, 3).join(", ") + (miss.length > 3 ? " …" : ""), true); return false; }
    const btn = $("dlUndertaking"); const old = btn.innerHTML; btn.disabled = true; btn.innerHTML = "তৈরি হচ্ছে…";
    try {
      const d = collect();
      let bytes, whoName;
      if (target.role === "attendant") { bytes = await renderAttendant(d, SIG.applicant.data, target.idx); whoName = (d.attendants[target.idx] && d.attendants[target.idx].name) || "attendant"; }
      else { bytes = await renderPatient(d, SIG.applicant.data); whoName = d.FULL_NAME || "patient"; }
      bytes = await ensurePdfSize(bytes);
      lastBytes = bytes;
      lastName = "Undertaking_" + (target.role === "attendant" ? "Attendant_" : "Patient_") + slugOf(whoName) + ".pdf";
      download(lastBytes, lastName);
      const within = lastBytes.length <= MAX_PDF_SIZE;
      showDone("অঙ্গিকারনামা ডাউনলোড হয়েছে · " + fmtSize(lastBytes.length) + (within ? "" : " ⚠ বড়"));
      toast("ডাউনলোড সম্পন্ন ✓ — " + whoName);
      return true;
    } catch (e) { console.error(e); toast("PDF তৈরিতে সমস্যা হয়েছে", true); return false; }
    finally { btn.disabled = false; btn.innerHTML = old; }
  }

  // ---------------- generate consent ----------------
  async function generateConsent() {
    const p = personData(target);
    const father = ($("cFather").value || "").trim(), mother = ($("cMother").value || "").trim();
    if (!father || !mother) { toast("বাবা ও মায়ের নাম দিন", true); return; }
    if (!($("HOSPITAL_NAME").value || "").trim()) { toast("হাসপাতালের নাম দরকার", true); return; }
    const btn = $("dlConsent"); const old = btn.innerHTML; btn.disabled = true; btn.innerHTML = "তৈরি হচ্ছে…";
    try {
      const dateStr = prettyDate(new Date().toISOString().slice(0, 10));
      const d = {
        date: dateStr, childName: p.name, childPass: p.passport, childDob: dmyFromIso(p.dobIso),
        hospital: ($("HOSPITAL_NAME").value || "").trim(), place: selectedMission.line2,
        father: { name: father, pass: ($("cFatherPass").value || "").trim(), mobile: ($("cFatherMobile").value || "").trim(), sig: SIG.father.data },
        mother: { name: mother, pass: ($("cMotherPass").value || "").trim(), mobile: ($("cMotherMobile").value || "").trim(), sig: SIG.mother.data }
      };
      let bytes = await renderConsent(d);
      bytes = await ensurePdfSize(bytes);
      download(bytes, "Parental_Consent_" + slugOf(p.name || "child") + ".pdf");
      showDone("সম্মতিপত্র ডাউনলোড হয়েছে · " + fmtSize(bytes.length));
      toast("সম্মতিপত্র ডাউনলোড সম্পন্ন ✓");
    } catch (e) { console.error(e); toast("সম্মতিপত্র তৈরিতে সমস্যা", true); }
    finally { btn.disabled = false; btn.innerHTML = old; }
  }
  function showDone(txt) { $("prepDone").classList.remove("hide"); $("prepDoneTxt").textContent = txt; }

  // ===========================================================
  //  views + modal steps
  // ===========================================================
  const show = id => $(id).classList.remove("hide");
  const hide = id => $(id).classList.add("hide");
  function gotoUpload() { show("uploadView"); hide("formView"); window.scrollTo({ top: 0, behavior: "smooth" }); }
  function showFormView() { hide("uploadView"); show("formView"); rebuildTargetSelector(); window.scrollTo({ top: 0, behavior: "smooth" }); }
  function goManual() {
    $("extractBanner").classList.remove("show");
    if (attCount() === 0) makeAttRow("", "", "");
    setTarget({ role: "patient", idx: null });
    if (!$("DATE_OF_FILLING").value) $("DATE_OF_FILLING").value = new Date().toISOString().slice(0, 10);
    showFormView();
  }

  // ===========================================================
  //  MISSION MODAL
  // ===========================================================
  function openMissionModal() {
    const wrap = $("missionList");
    wrap.innerHTML = MISSIONS.map(m =>
      '<label class="mission-opt' + (m.id === selectedMission.id ? " selected" : "") + '" data-id="' + m.id + '">' +
        '<span class="mission-radio"></span>' +
        '<span class="mission-icon">' + m.icon + '</span>' +
        '<span class="mission-info">' +
          '<span class="mission-top">' +
            '<span class="mission-city-name">' + m.city + '</span>' +
            '<span class="mission-badge' + (m.id === "dhaka" ? " hci" : "") + '">' + m.badge + '</span>' +
          '</span>' +
          '<span class="mission-type">' + m.type + ' of India</span>' +
        '</span>' +
        '<span class="mission-check">✓</span>' +
      '</label>'
    ).join("");

    wrap.querySelectorAll(".mission-opt").forEach(el => {
      el.addEventListener("click", () => {
        wrap.querySelectorAll(".mission-opt").forEach(x => x.classList.remove("selected"));
        el.classList.add("selected");
      });
    });

    $("missionModal").classList.add("show");
  }

  function closeMissionModal() { $("missionModal").classList.remove("show"); }

  function confirmMission() {
    const sel = $("missionList").querySelector(".mission-opt.selected");
    if (sel) {
      selectedMission = MISSIONS.find(m => m.id === sel.dataset.id) || MISSIONS[0];
    }
    closeMissionModal();
    openPick();
  }

  // ---- pick step ----
  function pickBtn(role, idx, role_label, icon, cls, name) {
    return '<button type="button" class="pick-btn ' + cls + '" data-role="' + role + '"' + (idx != null ? ' data-idx="' + idx + '"' : '') + '>' +
      '<span class="pic">' + icon + '</span>' +
      '<span class="pick-meta"><span class="role">' + role_label + '</span><span class="nm">' + (name || "—") + '</span></span>' +
      '<span class="arr">→</span></button>';
  }
  function openPick() {
    const pn = ($("FULL_NAME").value || "").trim();
    const atts = getAttendants();
    let html = pickBtn("patient", null, "রোগী · Patient", "🩺️", "pt", pn);
    atts.forEach((a, j) => { html += pickBtn("attendant", j, "অ্যাটেনডেন্ট " + (j + 1) + " · Attendant", "🤝🏼", "at", a.name); });
    $("pickList").innerHTML = html;
    $("pickList").querySelectorAll(".pick-btn").forEach(b => b.addEventListener("click", () => openPrepare({ role: b.dataset.role, idx: b.dataset.idx != null ? +b.dataset.idx : null })));
    $("pickHint").textContent = atts.length ? ("রোগী + " + atts.length + " জন অ্যাটেনডেন্ট পাওয়া গেছে") : "শুধু রোগী পাওয়া গেছে";
    // Show selected mission badge
    const badge = $("pickMissionBadge");
    if (badge) badge.textContent = "👉  " + selectedMission.line1 + ", " + selectedMission.line2;
    show("pickStep"); hide("prepStep");
    $("pickModal").classList.add("show");
  }
  function closeModal() { $("pickModal").classList.remove("show"); }

  // ---- prepare step ----
  function openPrepare(t) {
    setTarget(t);
    const key = t.role + ":" + (t.idx == null ? "-" : t.idx);
    if (key !== preparedKey) { resetAllSignatures(); preparedKey = key; }
    const p = personData(t);
    $("prepWho").textContent = p.name || "—";
    $("prepRole").textContent = t.role === "attendant" ? ("অ্যাটেনডেন্ট " + (t.idx + 1)) : "রোগী";
    const age = ageFromIso(p.dobIso);
    const minor = age != null && age < 18;
    $("prepAge").textContent = age != null ? ("বয়স ~ " + age + " বছর" + (minor ? " · ১৮-র কম" : " · প্রাপ্তবয়স্ক")) : "জন্মতারিখ নেই";
    $("prepAge").className = "chip-age" + (minor ? " minor" : (age != null ? " adult" : ""));
    $("consentBlock").classList.toggle("hide", !minor);
    $("consentChild").textContent = (p.name || "—") + (p.dobIso ? (" · DOB " + dmyFromIso(p.dobIso)) : "");
    $("prepDone").classList.add("hide");
    reflectAllSignatures();
    hide("pickStep"); show("prepStep");
    $("pickModal").classList.add("show");
  }

  // ---------------- invitation handling ----------------
  function setParsing(on) { $("parseLoad").classList.toggle("show", on); }
  async function handleInvitation(file) {
    if (!file || file.type !== "application/pdf") { toast("একটি PDF ফাইল দিন", true); return; }
    setParsing(true);
    try {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const text = await extractInvitation(bytes);
      const P = parseInvitation(text);
      if (!P.patient.name && !(P.attendants && P.attendants.length)) { toast("এই PDF থেকে তথ্য পড়া যায়নি — হাতে পূরণ করুন", true); goManual(); return; }
      parsed = P; preparedKey = null; applyExtractAll(P);
      openMissionModal();
    } catch (e) { console.error(e); toast("PDF পড়তে সমস্যা হয়েছে — হাতে পূরণ করুন", true); goManual(); }
    finally { setParsing(false); }
  }

  // ===========================================================
  //  wire up
  // ===========================================================
  function bindDrop(zoneId, inputId, onFile) {
    const dz = $(zoneId), fi = $(inputId);
    if (!dz || !fi) return;
    fi.addEventListener("change", e => { if (e.target.files[0]) onFile(e.target.files[0]); fi.value = ""; });
    ["dragover", "dragenter"].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add("drag"); }));
    ["dragleave", "drop"].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove("drag"); }));
    dz.addEventListener("drop", e => { const f = e.dataTransfer.files[0]; if (f) onFile(f); });
  }

  document.addEventListener("DOMContentLoaded", () => {
    $("yr").textContent = new Date().getFullYear();
    loadStore();

    // ── Video Tutorial Floating Popup ──
    (function () {
      const popup     = document.getElementById("vidPopup");
      const head      = document.getElementById("vpHead");
      const closeBtn  = document.getElementById("vpClose");
      const reopenBtn = document.getElementById("vidReopenBtn");
      const iframe    = document.getElementById("vpIframe");
      const coming    = document.getElementById("vpComing");
      if (!popup || !head) return;

      // VIDEO_URL সেট থাকলে iframe দেখাও
      if (VIDEO_URL) {
        if (iframe) { iframe.src = VIDEO_URL; iframe.style.display = ""; }
        if (coming) coming.style.display = "none";
      }

      // Close
      closeBtn && closeBtn.addEventListener("click", function (e) {
        e.stopPropagation();
        popup.style.display = "none";
        if (reopenBtn) reopenBtn.style.display = "flex";
      });

      // Reopen
      reopenBtn && reopenBtn.addEventListener("click", function () {
        popup.style.display = "";
        reopenBtn.style.display = "none";
      });

      // ── Drag ──
      var dragging = false, startX, startY, startL, startT;

      function beginDrag(ex, ey) {
        var rect = popup.getBoundingClientRect();
        popup.style.right  = "auto";
        popup.style.bottom = "auto";
        popup.style.left   = rect.left + "px";
        popup.style.top    = rect.top  + "px";
        startX = ex; startY = ey;
        startL = rect.left; startT = rect.top;
        dragging = true;
      }

      function moveDrag(ex, ey) {
        if (!dragging) return;
        var nx = startL + (ex - startX);
        var ny = startT + (ey - startY);
        var mxX = window.innerWidth  - popup.offsetWidth;
        var mxY = window.innerHeight - popup.offsetHeight;
        popup.style.left = Math.max(0, Math.min(mxX, nx)) + "px";
        popup.style.top  = Math.max(0, Math.min(mxY, ny)) + "px";
      }

      function endDrag() { dragging = false; }

      // Mouse drag — শুধু header-এ (close বাদে)
      head.addEventListener("mousedown", function (e) {
        if (closeBtn && (e.target === closeBtn || closeBtn.contains(e.target))) return;
        e.preventDefault();
        beginDrag(e.clientX, e.clientY);
      });
      document.addEventListener("mousemove", function (e) { moveDrag(e.clientX, e.clientY); });
      document.addEventListener("mouseup",   endDrag);

      // Touch drag
      head.addEventListener("touchstart", function (e) {
        if (closeBtn && (e.target === closeBtn || closeBtn.contains(e.target))) return;
        var t = e.touches[0];
        beginDrag(t.clientX, t.clientY);
      }, { passive: true });
      document.addEventListener("touchmove", function (e) {
        if (!dragging) return;
        e.preventDefault();
        var t = e.touches[0];
        moveDrag(t.clientX, t.clientY);
      }, { passive: false });
      document.addEventListener("touchend", endDrag);
    })();
    // ── /Video Popup ──
    if (!$("DATE_OF_FILLING").value) $("DATE_OF_FILLING").value = new Date().toISOString().slice(0, 10);
    rebuildTargetSelector();

    bindDrop("invDrop", "invInput", handleInvitation);
    $("manualLink").addEventListener("click", goManual);
    $("addAttBtn").addEventListener("click", () => makeAttRow("", "", ""));

    // form actions
    $("backBtn").addEventListener("click", gotoUpload);
    $("reopenPickBtn").addEventListener("click", openMissionModal);
    $("prepareBtn").addEventListener("click", () => { preparedKey = null; openMissionModal(); });
    $("clearBtn").addEventListener("click", () => {
      if (!confirm("সব ঘর মুছে ফেলবেন?")) return;
      FIELDS.forEach(f => $(f).value = ""); $("DOB_PATIENT").value = "";
      $("DATE_OF_FILLING").value = new Date().toISOString().slice(0, 10);
      clearAttRows(); makeAttRow("", "", ""); resetAllSignatures(); setTarget({ role: "patient", idx: null });
      saveStore(); $("extractBanner").classList.remove("show"); toast("সব ঘর মুছে ফেলা হয়েছে");
    });
    FIELDS.forEach(f => $(f).addEventListener("input", saveStore));
    $("DOB_PATIENT").addEventListener("input", saveStore);

    // mission modal
    $("missionConfirm").addEventListener("click", confirmMission);
    $("missionCancel").addEventListener("click", closeMissionModal);
    // outside click disabled — only close button closes modal

    // modal: pick + prepare
    $("pickCancel").addEventListener("click", closeModal);
    $("prepClose").addEventListener("click", closeModal);
    $("prepBack").addEventListener("click", openPick);
    $("prepEdit").addEventListener("click", () => { closeModal(); showFormView(); });
    // outside click disabled
    $("dlUndertaking").addEventListener("click", generate);
    $("dlConsent").addEventListener("click", generateConsent);

    // signature uploaders (3 slots)
    bindDrop("sigDrop", "sigInput", f => openSigFile("applicant", f));
    bindDrop("fSigDrop", "fSigInput", f => openSigFile("father", f));
    bindDrop("mSigDrop", "mSigInput", f => openSigFile("mother", f));
    $("sigClear").addEventListener("click", () => clearSig("applicant"));
    $("fSigClear").addEventListener("click", () => clearSig("father"));
    $("mSigClear").addEventListener("click", () => clearSig("mother"));
    $("sigEditBtn").addEventListener("click", () => editSig("applicant"));
    $("fSigEditBtn").addEventListener("click", () => editSig("father"));
    $("mSigEditBtn").addEventListener("click", () => editSig("mother"));

    // QR remote upload (phone → computer)
    $("sigCam").addEventListener("click", () => startRemote("applicant"));
    $("fSigCam").addEventListener("click", () => startRemote("father"));
    $("mSigCam").addEventListener("click", () => startRemote("mother"));

    // Direct camera (this device)
    $("sigDirectCam").addEventListener("click", () => openDirectCam("applicant"));
    $("fSigDirectCam").addEventListener("click", () => openDirectCam("father"));
    $("mSigDirectCam").addEventListener("click", () => openDirectCam("mother"));

    // Direct cam modal controls
    $("dcSnapBtn").addEventListener("click", snapDc);
    $("dcSendBtn").addEventListener("click", useDcPhoto);
    $("dcRetakeBtn").addEventListener("click", () => { $('dcPreview').classList.add('hide'); $('dcVideo').classList.remove('hide'); $('dcSnapBtn').classList.remove('hide'); $('dcSendBtn').classList.add('hide'); $('dcRetakeBtn').classList.add('hide'); startDcCam(); });
    $("dcFlipBtn").addEventListener("click", () => { dcFacing = dcFacing === 'environment' ? 'user' : 'environment'; startDcCam(); });
    $("dcClose").addEventListener("click", closeDcCam);
    // outside click disabled

    // phone / QR handoff
    if ($("qrBtn")) $("qrBtn").addEventListener("click", openFullToolQR);
    $("qrClose").addEventListener("click", closeQR);
    $("qrCopy").addEventListener("click", copyQRUrl);
    // outside click disabled

    // signature editor sliders
    $("adjBright").addEventListener("input", e => { SIG[activeSlot].adjust.bright = +e.target.value; $("valBright").textContent = e.target.value; renderSigEditor(); });
    $("adjContrast").addEventListener("input", e => { SIG[activeSlot].adjust.contrast = +e.target.value; $("valContrast").textContent = e.target.value; renderSigEditor(); });
    $("adjWhite").addEventListener("input", e => { SIG[activeSlot].adjust.white = +e.target.value; $("valWhite").textContent = e.target.value; renderSigEditor(); });
    $("adjRot").addEventListener("input", e => { SIG[activeSlot].rot = +e.target.value; $("valRot").textContent = e.target.value + "°"; renderSigEditor(); });
    $("applyCropBtn").addEventListener("click", applyCrop);
    $("bgRemoveBtn").addEventListener("click", applyBgRemove);
    $("resetCropBtn").addEventListener("click", resetCrop);
    $("resetAdjBtn").addEventListener("click", resetAdjust);
    $("sigEditDone").addEventListener("click", sigEditDone);
    $("sigEditCancel").addEventListener("click", sigEditCancel);

    const cv = $("sigCanvas");
    cv.addEventListener("mousedown",  cropMouseDown);
    document.addEventListener("mousemove", cropMouseMove);
    document.addEventListener("mouseup",   cropMouseUp);
    cv.addEventListener("touchstart", cropMouseDown, { passive: false });
    document.addEventListener("touchmove", e => { if (cropDrag) { e.preventDefault(); cropMouseMove(e); } }, { passive: false });
    document.addEventListener("touchend",  cropMouseUp);
  });
})();
